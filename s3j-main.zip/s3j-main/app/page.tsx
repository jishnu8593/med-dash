import App from '../App';

export default function Home() {
  return <App />;
}
